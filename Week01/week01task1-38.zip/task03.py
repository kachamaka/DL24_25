import numpy as np


if __name__ == '__main__':
    print("Answer: B.")