import numpy as np


if __name__ == '__main__':
    baseball = [180, 215, 210, 210, 188, 176, 209, 200]
    baseball_np = np.array(baseball)
    print("Baseball array:", baseball_np)
    print("Type of baseball array:", type(baseball_np))
    